package com.example.firstapplication;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.w3c.dom.Text;
public class Hangman extends AppCompatActivity {
    public int invalidGuesses;
    public int validGuesses;
    public boolean letterB = false;
    public boolean letterFirstI = false;
    public boolean letterSecondI = false;
    public boolean letterR = false;
    public boolean letterZ = false;
    public boolean letterE = false;
    public boolean letterT = false;
    public String Bb = "-";
    public String Ifirst = "-";
    public String Rr = "-";
    public String Zz = "-";
    public String Ee = "-";
    public String Isecond = "-";
    public String Tt = "-";
    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String firstName = getIntent().getStringExtra("FIRST_NAME");
        String lastName = getIntent().getStringExtra("LAST_NAME");
        String studentID = getIntent().getStringExtra("STUDENT_ID");
        LinearLayout firstLinearLayout=new LinearLayout(this);
        Button button = new Button(this);
        Button reset = new Button(this);
        TextView text1 = new TextView(this);
        TextView text2 = new TextView(this);
        TextView wordDisplay = new TextView(this);
        TextView head = new TextView(this);
        TextView body = new TextView(this);
        TextView rightArm = new TextView(this);
        TextView leftArm = new TextView(this);
        TextView rightLeg = new TextView(this);
        TextView leftLeg = new TextView(this);
        TextView guess = new TextView(this);
        EditText takeGuess = new EditText(this);
        TextView wrongGuess = new TextView(this);
        TextView wrongGuessCount = new TextView(this);
        TextView youLost = new TextView(this);
        TextView youWon = new TextView(this);
        LinearLayout secondLinearLayout=new LinearLayout(this);
        LinearLayout thirdLinearLayout=new LinearLayout(this);
        LinearLayout fourthLinearLayout=new LinearLayout(this);
        LinearLayout fifthLinearLayout=new LinearLayout(this);
        LinearLayout sixthLinearLayout=new LinearLayout(this);
        LinearLayout seventhLinearLayout=new LinearLayout(this);
        LinearLayout eighthLinearLayout=new LinearLayout(this);
        LinearLayout ninthLinearLayout=new LinearLayout(this);
        LinearLayout tenthLinearLayout = new LinearLayout(this);
        LinearLayout eleventhLinearLayout = new LinearLayout(this);
        LinearLayout twelfthLinearLayout = new LinearLayout(this);
        LinearLayout therteenthLinearLayout = new LinearLayout(this);
        LinearLayout fourteenthLinearLayout = new LinearLayout(this);
        LinearLayout fifteenthLinearLayout = new LinearLayout(this);
        firstLinearLayout.setOrientation(LinearLayout.VERTICAL);
        secondLinearLayout.setOrientation(LinearLayout.VERTICAL);
        secondLinearLayout.setPadding(0, 100, 0, 0);
        thirdLinearLayout.setOrientation(LinearLayout.HORIZONTAL);
        thirdLinearLayout.setGravity(1);
        fourthLinearLayout.setOrientation(LinearLayout.VERTICAL);
        fourthLinearLayout.setGravity(1);
        fifthLinearLayout.setOrientation(LinearLayout.VERTICAL);
        sixthLinearLayout.setOrientation(LinearLayout.VERTICAL);
        seventhLinearLayout.setOrientation(LinearLayout.HORIZONTAL);
        seventhLinearLayout.setGravity(1);
        eighthLinearLayout.setOrientation(LinearLayout.VERTICAL);
        ninthLinearLayout.setOrientation(LinearLayout.VERTICAL);
        tenthLinearLayout.setOrientation(LinearLayout.HORIZONTAL);
        eleventhLinearLayout.setOrientation(LinearLayout.HORIZONTAL);
        twelfthLinearLayout.setOrientation(LinearLayout.VERTICAL);
        twelfthLinearLayout.setGravity(1);
        therteenthLinearLayout.setOrientation(LinearLayout.VERTICAL);
        therteenthLinearLayout.setGravity(1);
        therteenthLinearLayout.setPadding(0,100,0,0);
        fourteenthLinearLayout.setOrientation(LinearLayout.VERTICAL);
        fourteenthLinearLayout.setGravity(1);
        fourteenthLinearLayout.setPadding(0,100,0,0);
        fifteenthLinearLayout.setOrientation(LinearLayout.VERTICAL);
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        button.setText("Submit Guess");

        reset.setText("reset Game");
        reset.setPadding(0,50,0,0);

        text1.setText(studentID + "_" + firstName + "_" + lastName);
        text1.setGravity(1);
        text1.setTextSize(15);
        text1.setPadding(0,50, 0, 0);

        text2.setText("TODO 1: ASCII hangman");
        text2.setGravity(1);
        text2.setTextSize(22);
        text2.setPadding(0, 30, 0, 0);

        head.setText("0");
        head.setTextSize(30);
        head.setGravity(1);

        body.setText("|");
        body.setTextSize(30);

        leftArm.setText("/");
        leftArm.setTextSize(30);

        rightArm.setText("\\");
        rightArm.setTextSize(30);

        leftLeg.setText("/");
        leftLeg.setTextSize(30);

        rightLeg.setText("\\");
        rightLeg.setTextSize(30);

        guess.setText("take a guess here");

        takeGuess.setHint("type letter guess here");

        youLost.setText("Sorry "+firstName+" "+lastName+"! You lost the game");
        youLost.setGravity(1);

        youWon.setText("Congratulations "+firstName+" "+lastName+",! You won the game");
        youWon.setGravity(1);
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (takeGuess.getText().toString()){
                    case "b":
                        if(letterB==false){
                            validGuesses=validGuesses+1;
                            letterB = true;
                            Bb = "B";
                        }else{
                            invalidGuesses = invalidGuesses+1;
                            wrongGuessCount.setText(String.valueOf(invalidGuesses));
                            if(invalidGuesses == 1){
                                twelfthLinearLayout.addView(head);
                            }
                            else if(invalidGuesses == 2){
                                fifthLinearLayout.addView(body);
                            }
                            else if(invalidGuesses == 3){
                                sixthLinearLayout.addView(rightArm);
                            }
                            else if(invalidGuesses == 4){
                                fourthLinearLayout.addView(leftArm);
                            }
                            else if(invalidGuesses == 5){
                                ninthLinearLayout.addView(rightLeg);
                            }
                            else if(invalidGuesses == 6){
                                eighthLinearLayout.addView(leftLeg);
                                fourteenthLinearLayout.addView(youLost);
                                firstLinearLayout.removeView(button);
                                firstLinearLayout.removeView(eleventhLinearLayout);
                                firstLinearLayout.removeView(tenthLinearLayout);
                                firstLinearLayout.removeView(wordDisplay);
                                firstLinearLayout.removeView(secondLinearLayout);
                                fourteenthLinearLayout.addView(reset);
                            }
                        }
                        break;
                    case "B":
                        if(letterB==false){
                            validGuesses=validGuesses+1;
                            letterB = true;
                            Bb = "B";
                        }else{
                            invalidGuesses = invalidGuesses+1;
                            wrongGuessCount.setText(String.valueOf(invalidGuesses));
                            if(invalidGuesses == 1){
                                twelfthLinearLayout.addView(head);
                            }
                            else if(invalidGuesses == 2){
                                fifthLinearLayout.addView(body);
                            }
                            else if(invalidGuesses == 3){
                                sixthLinearLayout.addView(rightArm);
                            }
                            else if(invalidGuesses == 4){
                                fourthLinearLayout.addView(leftArm);
                            }
                            else if(invalidGuesses == 5){
                                ninthLinearLayout.addView(rightLeg);
                            }
                            else if(invalidGuesses == 6){
                                eighthLinearLayout.addView(leftLeg);
                                fourteenthLinearLayout.addView(youLost);
                                firstLinearLayout.removeView(button);
                                firstLinearLayout.removeView(eleventhLinearLayout);
                                firstLinearLayout.removeView(tenthLinearLayout);
                                firstLinearLayout.removeView(wordDisplay);
                                firstLinearLayout.removeView(secondLinearLayout);
                                fourteenthLinearLayout.addView(reset);
                            }
                        }
                        break;
                    case "i":
                        if(letterFirstI==false && letterSecondI==false){
                            validGuesses=validGuesses+1;
                            letterFirstI = true;
                            Ifirst = "I";
                        }
                        else if (letterFirstI==true && letterSecondI==false) {
                            validGuesses=validGuesses+1;
                            letterSecondI = true;
                            Isecond = "I";
                        }else{
                            invalidGuesses = invalidGuesses+1;
                            wrongGuessCount.setText(String.valueOf(invalidGuesses));
                            if(invalidGuesses == 1){
                                twelfthLinearLayout.addView(head);
                            }
                            else if(invalidGuesses == 2){
                                fifthLinearLayout.addView(body);
                            }
                            else if(invalidGuesses == 3){
                                sixthLinearLayout.addView(rightArm);
                            }
                            else if(invalidGuesses == 4){
                                fourthLinearLayout.addView(leftArm);
                            }
                            else if(invalidGuesses == 5){
                                ninthLinearLayout.addView(rightLeg);
                            }
                            else if(invalidGuesses == 6){
                                eighthLinearLayout.addView(leftLeg);
                                fourteenthLinearLayout.addView(youLost);
                                firstLinearLayout.removeView(button);
                                firstLinearLayout.removeView(eleventhLinearLayout);
                                firstLinearLayout.removeView(tenthLinearLayout);
                                firstLinearLayout.removeView(wordDisplay);
                                firstLinearLayout.removeView(secondLinearLayout);
                                fourteenthLinearLayout.addView(reset);
                            }
                        }
                        break;
                    case "I":
                        if(letterFirstI==false && letterSecondI==false){
                            validGuesses=validGuesses+1;
                            letterFirstI = true;
                            Ifirst = "I";
                        }
                        else if (letterFirstI==true && letterSecondI==false) {
                            validGuesses=validGuesses+1;
                            letterSecondI = true;
                            Isecond = "I";
                        }else{
                            invalidGuesses = invalidGuesses+1;
                            wrongGuessCount.setText(String.valueOf(invalidGuesses));
                            if(invalidGuesses == 1){
                                twelfthLinearLayout.addView(head);
                            }
                            else if(invalidGuesses == 2){
                                fifthLinearLayout.addView(body);
                            }
                            else if(invalidGuesses == 3){
                                sixthLinearLayout.addView(rightArm);
                            }
                            else if(invalidGuesses == 4){
                                fourthLinearLayout.addView(leftArm);
                            }
                            else if(invalidGuesses == 5){
                                ninthLinearLayout.addView(rightLeg);
                            }
                            else if(invalidGuesses == 6){
                                eighthLinearLayout.addView(leftLeg);
                                fourteenthLinearLayout.addView(youLost);
                                firstLinearLayout.removeView(button);
                                firstLinearLayout.removeView(eleventhLinearLayout);
                                firstLinearLayout.removeView(tenthLinearLayout);
                                firstLinearLayout.removeView(wordDisplay);
                                firstLinearLayout.removeView(secondLinearLayout);
                                fourteenthLinearLayout.addView(reset);
                            }
                        }
                        break;
                    case "r":
                        if(letterR==false){
                            validGuesses=validGuesses+1;
                            letterR = true;
                            Rr = "R";
                        }else{
                            invalidGuesses = invalidGuesses+1;
                            wrongGuessCount.setText(String.valueOf(invalidGuesses));
                            if(invalidGuesses == 1){
                                twelfthLinearLayout.addView(head);
                            }
                            else if(invalidGuesses == 2){
                                fifthLinearLayout.addView(body);
                            }
                            else if(invalidGuesses == 3){
                                sixthLinearLayout.addView(rightArm);
                            }
                            else if(invalidGuesses == 4){
                                fourthLinearLayout.addView(leftArm);
                            }
                            else if(invalidGuesses == 5){
                                ninthLinearLayout.addView(rightLeg);
                            }
                            else if(invalidGuesses == 6){
                                eighthLinearLayout.addView(leftLeg);
                                fourteenthLinearLayout.addView(youLost);
                                firstLinearLayout.removeView(button);
                                firstLinearLayout.removeView(eleventhLinearLayout);
                                firstLinearLayout.removeView(tenthLinearLayout);
                                firstLinearLayout.removeView(wordDisplay);
                                firstLinearLayout.removeView(secondLinearLayout);
                                fourteenthLinearLayout.addView(reset);
                            }
                        }
                        break;
                    case "R":
                        if(letterR==false){
                            validGuesses=validGuesses+1;
                            letterR = true;
                            Rr = "R";
                        }else{
                            invalidGuesses = invalidGuesses+1;
                            wrongGuessCount.setText(String.valueOf(invalidGuesses));
                            if(invalidGuesses == 1){
                                twelfthLinearLayout.addView(head);
                            }
                            else if(invalidGuesses == 2){
                                fifthLinearLayout.addView(body);
                            }
                            else if(invalidGuesses == 3){
                                sixthLinearLayout.addView(rightArm);
                            }
                            else if(invalidGuesses == 4){
                                fourthLinearLayout.addView(leftArm);
                            }
                            else if(invalidGuesses == 5){
                                ninthLinearLayout.addView(rightLeg);
                            }
                            else if(invalidGuesses == 6){
                                eighthLinearLayout.addView(leftLeg);
                                fourteenthLinearLayout.addView(youLost);
                                firstLinearLayout.removeView(button);
                                firstLinearLayout.removeView(eleventhLinearLayout);
                                firstLinearLayout.removeView(tenthLinearLayout);
                                firstLinearLayout.removeView(wordDisplay);
                                firstLinearLayout.removeView(secondLinearLayout);
                                fourteenthLinearLayout.addView(reset);
                            }
                        }
                        break;
                    case "z":
                        if(letterZ==false){
                            validGuesses=validGuesses+1;
                            letterZ = true;
                            Zz = "Z";
                        }else{
                            invalidGuesses = invalidGuesses+1;
                            wrongGuessCount.setText(String.valueOf(invalidGuesses));
                            if(invalidGuesses == 1){
                                twelfthLinearLayout.addView(head);
                            }
                            else if(invalidGuesses == 2){
                                fifthLinearLayout.addView(body);
                            }
                            else if(invalidGuesses == 3){
                                sixthLinearLayout.addView(rightArm);
                            }
                            else if(invalidGuesses == 4){
                                fourthLinearLayout.addView(leftArm);
                            }
                            else if(invalidGuesses == 5){
                                ninthLinearLayout.addView(rightLeg);
                            }
                            else if(invalidGuesses == 6){
                                eighthLinearLayout.addView(leftLeg);
                                fourteenthLinearLayout.addView(youLost);
                                firstLinearLayout.removeView(button);
                                firstLinearLayout.removeView(eleventhLinearLayout);
                                firstLinearLayout.removeView(tenthLinearLayout);
                                firstLinearLayout.removeView(wordDisplay);
                                firstLinearLayout.removeView(secondLinearLayout);
                                fourteenthLinearLayout.addView(reset);
                            }
                        }
                        break;
                    case "Z":
                        if(letterZ==false){
                            validGuesses=validGuesses+1;
                            letterZ = true;
                            Zz = "Z";
                        }else{
                            invalidGuesses = invalidGuesses+1;
                            wrongGuessCount.setText(String.valueOf(invalidGuesses));
                            if(invalidGuesses == 1){
                                twelfthLinearLayout.addView(head);
                            }
                            else if(invalidGuesses == 2){
                                fifthLinearLayout.addView(body);
                            }
                            else if(invalidGuesses == 3){
                                sixthLinearLayout.addView(rightArm);
                            }
                            else if(invalidGuesses == 4){
                                fourthLinearLayout.addView(leftArm);
                            }
                            else if(invalidGuesses == 5){
                                ninthLinearLayout.addView(rightLeg);
                            }
                            else if(invalidGuesses == 6){
                                eighthLinearLayout.addView(leftLeg);
                                fourteenthLinearLayout.addView(youLost);
                                firstLinearLayout.removeView(button);
                                firstLinearLayout.removeView(eleventhLinearLayout);
                                firstLinearLayout.removeView(tenthLinearLayout);
                                firstLinearLayout.removeView(wordDisplay);
                                firstLinearLayout.removeView(secondLinearLayout);
                                fourteenthLinearLayout.addView(reset);
                            }
                        }
                        break;
                    case "e":
                        if(letterE==false){
                            validGuesses=validGuesses+1;
                            letterE = true;
                            Ee = "E";
                        }else{
                            invalidGuesses = invalidGuesses+1;
                            wrongGuessCount.setText(String.valueOf(invalidGuesses));
                            if(invalidGuesses == 1){
                                twelfthLinearLayout.addView(head);
                            }
                            else if(invalidGuesses == 2){
                                fifthLinearLayout.addView(body);
                            }
                            else if(invalidGuesses == 3){
                                sixthLinearLayout.addView(rightArm);
                            }
                            else if(invalidGuesses == 4){
                                fourthLinearLayout.addView(leftArm);
                            }
                            else if(invalidGuesses == 5){
                                ninthLinearLayout.addView(rightLeg);
                            }
                            else if(invalidGuesses == 6){
                                eighthLinearLayout.addView(leftLeg);
                                fourteenthLinearLayout.addView(youLost);
                                firstLinearLayout.removeView(button);
                                firstLinearLayout.removeView(eleventhLinearLayout);
                                firstLinearLayout.removeView(tenthLinearLayout);
                                firstLinearLayout.removeView(wordDisplay);
                                firstLinearLayout.removeView(secondLinearLayout);
                                fourteenthLinearLayout.addView(reset);
                            }
                        }
                        break;
                    case "E":
                        if(letterE==false){
                            validGuesses=validGuesses+1;
                            letterE = true;
                            Ee = "E";
                        }else{
                            invalidGuesses = invalidGuesses+1;
                            wrongGuessCount.setText(String.valueOf(invalidGuesses));
                            if(invalidGuesses == 1){
                                twelfthLinearLayout.addView(head);
                            }
                            else if(invalidGuesses == 2){
                                fifthLinearLayout.addView(body);
                            }
                            else if(invalidGuesses == 3){
                                sixthLinearLayout.addView(rightArm);
                            }
                            else if(invalidGuesses == 4){
                                fourthLinearLayout.addView(leftArm);
                            }
                            else if(invalidGuesses == 5){
                                ninthLinearLayout.addView(rightLeg);
                            }
                            else if(invalidGuesses == 6){
                                eighthLinearLayout.addView(leftLeg);
                                fourteenthLinearLayout.addView(youLost);
                                firstLinearLayout.removeView(button);
                                firstLinearLayout.removeView(eleventhLinearLayout);
                                firstLinearLayout.removeView(tenthLinearLayout);
                                firstLinearLayout.removeView(wordDisplay);
                                firstLinearLayout.removeView(secondLinearLayout);
                                therteenthLinearLayout.addView(reset);
                            }
                        }
                        break;
                    case "t":
                        if(letterT==false){
                            validGuesses=validGuesses+1;
                            letterT = true;
                            Tt = "T";
                        }else{
                            invalidGuesses = invalidGuesses+1;
                            wrongGuessCount.setText(String.valueOf(invalidGuesses));
                            if(invalidGuesses == 1){
                                twelfthLinearLayout.addView(head);
                            }
                            else if(invalidGuesses == 2){
                                fifthLinearLayout.addView(body);
                            }
                            else if(invalidGuesses == 3){
                                sixthLinearLayout.addView(rightArm);
                            }
                            else if(invalidGuesses == 4){
                                fourthLinearLayout.addView(leftArm);
                            }
                            else if(invalidGuesses == 5){
                                ninthLinearLayout.addView(rightLeg);
                            }
                            else if(invalidGuesses == 6){
                                eighthLinearLayout.addView(leftLeg);
                                fourteenthLinearLayout.addView(youLost);
                                firstLinearLayout.removeView(button);
                                firstLinearLayout.removeView(eleventhLinearLayout);
                                firstLinearLayout.removeView(tenthLinearLayout);
                                firstLinearLayout.removeView(wordDisplay);
                                firstLinearLayout.removeView(secondLinearLayout);
                                fourteenthLinearLayout.addView(reset);
                            }
                        }
                        break;
                    case "T":
                        if(letterT==false){
                            validGuesses=validGuesses+1;
                            letterT = true;
                            Tt = "T";
                        }else{
                            invalidGuesses = invalidGuesses+1;
                            wrongGuessCount.setText(String.valueOf(invalidGuesses));
                            if(invalidGuesses == 1){
                                twelfthLinearLayout.addView(head);
                            }
                            else if(invalidGuesses == 2){
                                fifthLinearLayout.addView(body);
                            }
                            else if(invalidGuesses == 3){
                                sixthLinearLayout.addView(rightArm);
                            }
                            else if(invalidGuesses == 4){
                                fourthLinearLayout.addView(leftArm);
                            }
                            else if(invalidGuesses == 5){
                                ninthLinearLayout.addView(rightLeg);
                            }
                            else if(invalidGuesses == 6){
                                eighthLinearLayout.addView(leftLeg);
                                fourteenthLinearLayout.addView(youLost);
                                firstLinearLayout.removeView(button);
                                firstLinearLayout.removeView(eleventhLinearLayout);
                                firstLinearLayout.removeView(tenthLinearLayout);
                                firstLinearLayout.removeView(wordDisplay);
                                firstLinearLayout.removeView(secondLinearLayout);
                                fourteenthLinearLayout.addView(reset);
                            }
                        }
                        break;
                    default:
                        invalidGuesses = invalidGuesses+1;
                        wrongGuessCount.setText(String.valueOf(invalidGuesses));

                        if(invalidGuesses == 1){
                            twelfthLinearLayout.addView(head);
                        }
                        else if(invalidGuesses == 2){
                            fifthLinearLayout.addView(body);
                        }
                        else if(invalidGuesses == 3){
                            sixthLinearLayout.addView(rightArm);
                        }
                        else if(invalidGuesses == 4){
                            fourthLinearLayout.addView(leftArm);
                        }
                        else if(invalidGuesses == 5){
                            ninthLinearLayout.addView(rightLeg);
                        }
                        else if(invalidGuesses == 6){
                            eighthLinearLayout.addView(leftLeg);
                            fourteenthLinearLayout.addView(youLost);
                            firstLinearLayout.removeView(button);
                            firstLinearLayout.removeView(eleventhLinearLayout);
                            firstLinearLayout.removeView(tenthLinearLayout);
                            firstLinearLayout.removeView(wordDisplay);
                            firstLinearLayout.removeView(secondLinearLayout);
                            fourteenthLinearLayout.addView(reset);
                        }
                    break;
                }

                if(validGuesses==7){
                    therteenthLinearLayout.addView(youWon);
                    firstLinearLayout.removeView(button);
                    firstLinearLayout.removeView(eleventhLinearLayout);
                    firstLinearLayout.removeView(tenthLinearLayout);
                    firstLinearLayout.removeView(wordDisplay);
                    firstLinearLayout.removeView(secondLinearLayout);
                    therteenthLinearLayout.addView(reset);
                }

                wordDisplay.setText(""+Bb+""+Ifirst+""+Rr.toString()+""+Zz.toString()+""+Ee.toString()+""+Isecond.toString()+""+Tt.toString());
                wordDisplay.setTextSize(100);
                wordDisplay.setGravity(1);
            }
        });
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Hangman.this,MainActivity.class);
                Hangman.this.startActivity(intent);
                finish();
            }
        });
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        wrongGuess.setText("wrong Guesses Counter: ");

        secondLinearLayout.addView(twelfthLinearLayout);

        thirdLinearLayout.addView(fourthLinearLayout);
        thirdLinearLayout.addView(fifthLinearLayout);
        thirdLinearLayout.addView(sixthLinearLayout);
        secondLinearLayout.addView(thirdLinearLayout);

        seventhLinearLayout.addView(eighthLinearLayout);
        seventhLinearLayout.addView(ninthLinearLayout);
        secondLinearLayout.addView(seventhLinearLayout);

        tenthLinearLayout.addView(guess);
        tenthLinearLayout.addView(takeGuess);
        tenthLinearLayout.setGravity(1);
        tenthLinearLayout.setPadding(0, 0, 0, 50);

        eleventhLinearLayout.addView(wrongGuess);
        eleventhLinearLayout.addView(wrongGuessCount);
        eleventhLinearLayout.setGravity(1);
        eleventhLinearLayout.setPadding(0, 50, 0, 0);

        firstLinearLayout.addView(text1);
        firstLinearLayout.addView(text2);
        firstLinearLayout.addView(secondLinearLayout);
        firstLinearLayout.addView(wordDisplay);
        firstLinearLayout.addView(tenthLinearLayout);
        firstLinearLayout.addView(button);
        firstLinearLayout.addView(eleventhLinearLayout);
        firstLinearLayout.addView(therteenthLinearLayout);
        firstLinearLayout.addView(fourteenthLinearLayout);


        setContentView(firstLinearLayout);
    }
}